const useMediaStreamTrack = (track: any) => track?.mediaStreamTrack;
export default useMediaStreamTrack;
