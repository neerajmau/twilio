export default module.exports = () => {};
